module.exports = {
  networks: {
    development: {
      host: "localhost", //本地地址，因为是在本机上建立的节点
      port: 8545,        //Ethereum的rpc监听的端口号，默认是8545
      network_id: 999    // 自定义网络号
    }
  }
};